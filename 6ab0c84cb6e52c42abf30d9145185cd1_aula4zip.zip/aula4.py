
def obter_notas():
    notas = []
    quantidade_notas = int(input("Digite o número de notas: "))
    
    for _ in range(quantidade_notas):
        nota = float(input("Digite a nota: "))
        notas.append(nota)
    
    return notas

def calcular_media(notas):
    if len(notas) == 0:
        return 0
    return sum(notas) / len(notas)

def verificar_situacao(media):
    if media == 10:
        return "Parabéns, sua média é 10!"
    elif media >= 7:
        return "Aprovado"
    else:
        return "Reprovado"


notas_aluno = obter_notas()


media_aluno = calcular_media(notas_aluno)


situacao_aluno = verificar_situacao(media_aluno)
print(f"Média: {media_aluno:.2f} - Situação: {situacao_aluno}")